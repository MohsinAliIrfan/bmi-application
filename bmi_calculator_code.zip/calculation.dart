
import 'package:flutter/cupertino.dart';

class Cal {

  int weight = 0;
  int height = 0;
  double total = 0;

  Cal({this.height, this.weight});

  void setheight(int height) {
    this.height = height;
  }
  void setweight(int weight) {
    this.weight = weight;
  }
  void calculate() {
    height = height*height;
    total = weight/height;
    total *= 10000;
  }
  String check(){
    if(total >= 25)
      return 'Over-Weight';

    else if(total>18.5)
      return 'Normal';

    else return 'Under-Weight';
  }
  String giveadvice(){
    if(total >= 25)
      return 'Its not a big problem, u juest need to exercise more. ;D';

    else if(total>18.5)
      return 'You are absolutely Fine, just mentain it. :D';

    else return 'Hey there, you need to eat, come on, eat more, ;D';
  }

  String gettotal() {return total.toStringAsFixed(1);}
}