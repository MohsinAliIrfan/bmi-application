import 'package:flutter/material.dart';
import 'reusable.dart';
import 'BottomButton.dart';
import 'inputpage.dart';

void main(){
  runApp(result());
}

class result extends StatelessWidget {
  @override

  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData.dark().copyWith( // .dark() will automatically chaange the text color to white
        primaryColor: Color(0xFF132013),
        scaffoldBackgroundColor: Color(0xFF132013),
        ),
      home: Scaffold(
        appBar: AppBar(
          title: Center(
            child: Text(
              'BMI CALCULATOR'
            ),
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: Container(
                 padding: EdgeInsets.all(15.0),
                alignment: Alignment.bottomLeft,
                child: Text(
                  'YOUR RESULT',
                  style: TextStyle(
                    fontSize: 35,
                    fontWeight: FontWeight.w900
                  ),
                ),
              ),
            ),
            Expanded(
              flex: 5 ,// it is being used here so that it could take more space,
              child: reuseableContainer(colour: Color(0XFF1D1E33),
                cardchild: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly, // it will provide space between the  children of the row
                  crossAxisAlignment: CrossAxisAlignment.stretch, //used it so that our Cokumn occupies all the space horizontaly
                  children: [
                    Center(
                      child: Text(
                       obj.check(),
                        style: TextStyle(
                          fontSize: 25.0,
                          fontWeight: FontWeight.w400,
                          color: Colors.green,
                        ),
                      ),
                    ),
                    Center(
                      child: Text(
                       obj.gettotal(), // this obj is an object imported from inputpage,dart file
                        style: TextStyle(
                          fontSize: 60.0,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    Center(
                        child: Text(
                          obj.giveadvice(),
                          style: TextStyle(
                            fontSize: 20.0,
                            fontWeight: FontWeight.w400,
                          ),
                        ),
                    ),
                  ],
                )

                ),
            ),
            bottombutton(
                ontap:(){
                  Navigator.pop(context);
                },
                data: 'RE CALCULATE'
            ),
          ],
        ),
      )
    );
  }
}
