import 'package:flutter/material.dart';

const styling = TextStyle(
  fontSize: 20.0,
  color: Color(0xFF8D8E98),
);

const style2 = TextStyle(
  fontSize: 60.0,
  color: Colors.white,
  fontWeight: FontWeight.bold
);