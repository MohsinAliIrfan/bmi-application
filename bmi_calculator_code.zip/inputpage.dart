import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'reusable.dart';
import 'containers.dart';
import 'textstyle.dart';
import 'resultscreen.dart';
import 'BottomButton.dart';
import 'calculation.dart';

enum gender{male,female}
Cal obj = Cal(); // this variable is duobles bcz i have to use it another file where this file will be imported,  is being used in resultscreen file

class InputPage extends StatefulWidget {
  @override
  _InputPageState createState() => _InputPageState();
}
class _InputPageState extends State<InputPage> {
  @override

  gender type;
  int height = 120;
  int heightforslider = 120;
  int weight = 60;
  int age = 20;


  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(
            child: Text(
                'BMI CALCULATOR'
            )
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Row(
              children: [ 
                Expanded(
                  child: reuseableContainer(
                    fun: (){
                      setState(() {
                       type = gender.male;
                      });
                    },
                  colour: type == gender.male ? inactivecolor: cardcolor,
                    cardchild: ColumnClass(icon_var: FontAwesomeIcons.mars, text_var: 'Male',), // the coulumnClass constructor is called here
              ),
                ),
                Expanded(
                  child: reuseableContainer(
                      fun: (){
                        setState(() {
                          type = gender.female;
                        });
                      },
                    colour: type == gender.female ? inactivecolor : cardcolor,
                    cardchild: ColumnClass(icon_var: FontAwesomeIcons.venus, text_var: 'FeMale')
                  ),
                ),
              ]
            ),
          ),
          Expanded(
            child: reuseableContainer(
              colour: other_container_color,// we are using 'colour' here as a property bcz colour is the object of Color, colour is defined in resuableContainer stateless class
              cardchild: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'HEGIHT',
                    style: styling,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Text(
                        height.toString(),
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 40,
                        ),
                      ),
                      Text(
                        'cm',
                      )
                    ],
                  ),
                  SliderTheme( // we can use slider theme to change to poeperty of the slider
                    data: SliderTheme.of(context).copyWith( // we will have to use to .of and them copywith then we can cheange properties
                      activeTrackColor: Colors.white,
                      inactiveTrackColor: Color(0xFF8D8E98),
                      thumbColor: Color(0xFFEB1555),
                      thumbShape: RoundSliderThumbShape( // used to change the size of the circle of the slider
                        enabledThumbRadius: 15,
                      )
                    ),
                    child: Slider(
                      value: height.toDouble(),
                      min: 120.0,
                      max: 220.0,
                      onChanged: (double data){
                        setState(() {
                          height = data.round();
                          obj.setheight(height);
                        });
                      },

                    ),
                  ),
                ],
              ),
            ),

          ),
          Expanded(
            child: Row(
                children: [
                  Expanded(
                    child: reuseableContainer(
                      colour: other_container_color,
                        cardchild: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Weight",
                              style: styling,
                            ),
                            SizedBox(
                              height: 10.0
                            ),
                            Text(
                              weight.toString(),
                              style: style2,
                            ),
                            Row(
                             mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Iconforbottomconatiner(
                                  icon: FontAwesomeIcons.minus,
                                  onPressed: (){
                                    setState(() {
                                      weight--;
                                      obj.setweight(weight);
                                    });
                                    },
                                ),
                                SizedBox(
                                  width: 35.0
                                ),
                                 Iconforbottomconatiner(
                                   icon: FontAwesomeIcons.plus,
                                   onPressed: (){
                                     setState(() {
                                       weight++;
                                       obj.setweight(weight);
                                   });
                                },
    ),
                              ],
                            )
                          ],
                        )
                    ),

                  ),
                  Expanded(
                    child: reuseableContainer(
                      colour: other_container_color,
                        cardchild: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Age",
                              style: styling,
                            ),
                            SizedBox(
                                height: 10.0
                            ),
                            Text(
                              age.toString(),
                              style: style2,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Iconforbottomconatiner(
                                  icon: FontAwesomeIcons.minus,
                                  onPressed: (){
                                    setState(() {
                                      age--;
                                    });
                                  },
                                ),
                                SizedBox(
                                    width: 35.0
                                ),
                                Iconforbottomconatiner(
                                  icon: FontAwesomeIcons.plus,
                                  onPressed: (){
                                    setState(() {
                                      age++;
                                    });
                                  },
                                ),
                              ],
                            )
                          ],
                        )
                    ),
                  ),
                ]
            ),
          ),
          SizedBox(
            height: 10.0
          ),
          bottombutton(
            ontap: (){
              obj = Cal(height: height,weight: weight); // using an constructor here cz when i'll come back from the result screen and press the calculate button again withou chainging the values, the old values will be passed again to our Cal class i.e calulates all the bmi, it will show us the same result again, and if we even change the values, it will show us the new result depedning upon our values
              obj.calculate();
              Navigator.push(
              context, MaterialPageRoute(
                  builder: (context) => result()
             )
              );
              },
              data: 'Calculate'
              ),
        ],
      )
    );
  }
}

class Iconforbottomconatiner extends StatelessWidget {
  @override

  final IconData icon;
  final Function onPressed;

  Iconforbottomconatiner({@required this.icon, @required this.onPressed});

  Widget build(BuildContext context) {
    return RawMaterialButton(
      onPressed: onPressed,
      elevation: 66.0, //used for making a shadow under the icon or button
      constraints: BoxConstraints.tightFor(
        height: 56,
        width: 56,
      ),
      shape: CircleBorder(),
      fillColor: Color(0xFF8D8E98),
      child: Icon(icon),
    );
  }
}
