import 'package:flutter/material.dart';
import 'inputpage.dart';

void main(){
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark().copyWith( // .dark() will automatically chaange the text color to white
        primaryColor: Color(0xFF132013),
      scaffoldBackgroundColor: Color(0xFF132013),
      //  backgroundColor: Colors.black,
      ),
      home:InputPage(),
    );
  }
}