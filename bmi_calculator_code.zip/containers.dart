import 'package:flutter/material.dart';
import 'textstyle.dart';

const cardcolor = Color(0xFF111328);
const inactivecolor = Color(0XFF1D1E33);
const other_container_color = Color(0XFF1D1E33);

class ColumnClass extends StatelessWidget {
  @override

  final IconData icon_var;
  final String text_var;

  ColumnClass({@required this.icon_var, @ required this.text_var});

  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          icon_var, // the icon passed from where the constructor is called
          size: 70.0,
        ),
        SizedBox(height: 15.0),
        Text(
          text_var,
          style: styling,
        ),
      ],
    );
  }
}