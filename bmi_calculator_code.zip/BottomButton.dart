import 'package:flutter/material.dart';

class bottombutton extends StatelessWidget {

  final Function ontap;
  final String data;

  bottombutton({@required this.ontap, @required this.data});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        color: Colors.pink,
        child: Center(
          child: Text(
            data,
          ),
        ),
        padding: EdgeInsets.symmetric(horizontal: 30.0),

        height: 50.0,
        width: double.infinity,
        //margin: EdgeInsets.
        //height: 5.0,
        //width: 60.0,
      ),
    );
  }
}