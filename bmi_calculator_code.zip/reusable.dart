import 'package:flutter/material.dart';

class reuseableContainer extends StatelessWidget {
  @override

  final Widget cardchild;
  final  Color colour; // making an var or object of Color so that we can pass the value whenever this class or stateless widget is called
  final Function fun;
  reuseableContainer({@required this.colour, this.cardchild, this.fun}); // the value passed here will be used as the color of the partiular container

  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: fun,
      child: Container(
          child: cardchild,
          margin: EdgeInsets.all(7.0),
          decoration: BoxDecoration(
              color: colour,
              borderRadius: BorderRadius.circular(10.0)
          )
      ),
    );
  }
}